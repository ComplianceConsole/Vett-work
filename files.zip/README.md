# vett.work — Go Live Checklist

## File Structure
```
/
├── index.html              ← Homepage (split + job board)
├── candidate.html          ← Candidate / $19.99 video cover letter
├── employer.html           ← Employer / post a role
├── netlify.toml            ← Netlify config
└── netlify/
    └── functions/
        ├── send-email.js   ← Email function (Microsoft SMTP)
        └── package.json    ← nodemailer dependency
```

---

## Step 1 — Deploy to Netlify

1. Drag the entire folder into Netlify drop (app.netlify.com/drop)
2. Go to Site Settings → Domain Management
3. Add custom domain: vett.work
4. Follow DNS instructions (add the Netlify DNS records at your registrar)

---

## Step 2 — Set Environment Variables in Netlify

Go to Site Settings → Environment Variables and add:

```
SMTP_USER        hello@vett.work       (your Microsoft 365 email)
SMTP_PASS        your-password         (your Microsoft 365 password)
```

That's it for email. No Resend needed right now.

---

## Step 3 — Add Stripe Keys to HTML files

In candidate.html and employer.html, find the CONFIG block at the top of the <script> tag and replace the placeholder values:

```javascript
const CONFIG = {
  STRIPE_PUBLISHABLE_KEY: 'pk_live_...',        // Your Stripe publishable key
  STRIPE_PRICE_ID_INTERVIEW: 'price_...',        // $19.99 one-time
  STRIPE_PRICE_ID_ADHOC: 'price_...',            // $29.99 one-time
  STRIPE_PRICE_ID_MONTHLY: 'price_...',          // $199/month
  STRIPE_PRICE_ID_BASE: 'price_...',             // $99 one-time (employer)
  STRIPE_PRICE_ID_MID: 'price_...',              // $199 one-time (employer)
  STRIPE_PRICE_ID_PRO: 'price_...',              // $299/month (employer)
};
```

---

## Step 4 — Create Stripe Products

In your Stripe dashboard create these products:

| Product | Price | Type |
|---|---|---|
| Video Cover Letter | $19.99 | One-time |
| Role-Specific Interview | $29.99 | One-time |
| Role-Specific Unlimited | $199.00 | Monthly recurring |
| Base Listing | $99.00 | One-time |
| Mid Listing | $199.00 | One-time |
| Pro Subscription | $299.00 | Monthly recurring |

Copy each Price ID (starts with price_) into the CONFIG block above.

---

## Step 5 — Set up Microsoft 365 Email

1. Purchase Microsoft 365 Business Basic through GoDaddy (same as wadestrong.com.au)
2. Set up hello@vett.work
3. Add the SMTP_USER and SMTP_PASS environment variables in Netlify (Step 2)
4. Redeploy

---

## Adding Real Job Listings

When you have real roles to list, open index.html and find the commented-out job card example:

```html
<!-- EXAMPLE JOB CARDS — uncomment and duplicate when real listings exist
<div class="job-card" data-category="operations">
  ...
</div>
-->
```

Uncomment it, fill in the real details, and duplicate for each listing. The search and filter will work automatically.

---

## Stripe Webhook (for post-purchase flow)

Once the product build starts (candidate recording flow), you'll need a Stripe webhook to:
- Confirm payment
- Unlock the recording interface for the candidate
- Store the purchase in Supabase

This will be set up during the product build phase.

---

## Support
Built on: Netlify · Stripe · Microsoft 365 SMTP · Supabase (coming in product build)
